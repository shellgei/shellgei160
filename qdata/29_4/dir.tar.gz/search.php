word={a..z}{a..z}{a..z}
page={00..99}
num={00..99}
