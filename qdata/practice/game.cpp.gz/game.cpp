#include <iostream>
using namespace std;

int main()
{
	srand(time(NULL));
	cout << rand() << "は💩より大きい？（y/n）" << endl;
	string s;
	cin >> s;
	cout << "知らねえ" << endl;
}
